package com.tilttalk.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tilttalk.app.ui.theme.TiltTalkColors
import com.tilttalk.app.ui.theme.TiltTalkTheme

// =============================================================================
// DATA MODELS & PRESETS
// =============================================================================

enum class CommandType(
    val rawIntent: String,
    val spokenText: String,
    val isEmergency: Boolean = false,
    val icon: ImageVector
) {
    HELP("HELP", "I need help", false, Icons.Outlined.Info),
    WATER("WATER", "I need water", false, Icons.Outlined.WaterDrop),
    FOOD("FOOD", "I need food", false, Icons.Outlined.Restaurant),
    RESTROOM("RESTROOM", "I need the restroom", false, Icons.Outlined.Wc),
    YES("YES", "Yes", false, Icons.Outlined.CheckCircle),
    NO("NO", "No", false, Icons.Outlined.Cancel),
    CALL("CALL", "Please call someone", false, Icons.Outlined.Call),
    PAIN("PAIN", "I am in pain", true, Icons.Outlined.WarningAmber),
    EMERGENCY("EMERGENCY", "EMERGENCY — Assistance required", true, Icons.Outlined.ReportProblem),
    STOP("STOP", "Stop", false, Icons.Outlined.PanTool),
    NO_COMMAND("NO COMMAND", "No active communication request", false, Icons.Outlined.HourglassEmpty)
}

data class HistoryItem(
    val id: String,
    val command: CommandType,
    val time: String,
    val date: String,
    val statusNote: String
)

data class PatientProfileState(
    val fullName: String = "",
    val dob: String = "",
    val calculatedAge: Int = 0,
    val wardLocation: String = "",
    val primaryNurse: String = "",
    val emergencyContact: String = "",
    val sensorMode: String = "Head-Tilt (MPU6050 Threshold: Medium)",
    val sensitivityLevel: Int = 3,
    val dwellTimeSeconds: Float = 1.5f,
    val audioFeedbackOnDwell: Boolean = true
)

// =============================================================================
// REUSABLE TOP BAR & BOTTOM NAVIGATION
// =============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TiltTalkTopAppBar(
    title: String = "TiltTalk",
    subtitle: String? = null,
    showBackButton: Boolean = false,
    onBackClick: () -> Unit = {},
    showSettingsAction: Boolean = true,
    onSettingsClick: () -> Unit = {}
) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color.White
        ),
        title = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.RecordVoiceOver,
                        contentDescription = null,
                        tint = TiltTalkColors.NavyPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TiltTalkColors.NavyPrimary
                        )
                    )
                }
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = TiltTalkColors.TextSecondary
                        )
                    )
                }
            }
        },
        navigationIcon = {
            if (showBackButton) {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = TiltTalkColors.NavyPrimary
                    )
                }
            }
        },
        actions = {
            if (showSettingsAction) {
                IconButton(onClick = onSettingsClick) {
                    Icon(
                        imageVector = Icons.Outlined.Settings,
                        contentDescription = "Settings",
                        tint = TiltTalkColors.NavyPrimary
                    )
                }
            }
        }
    )
}

@Composable
fun TiltTalkBottomBar(
    currentTab: Int,
    onTabSelected: (Int) -> Unit
) {
    NavigationBar(
        containerColor = Color.White,
        tonalElevation = 0.dp,
        modifier = Modifier.border(BorderStroke(1.dp, TiltTalkColors.BorderSubtle))
    ) {
        val items = listOf(
            Triple("Home", Icons.Outlined.Home, Icons.Filled.Home),
            Triple("History", Icons.Outlined.History, Icons.Filled.History),
            Triple("Settings", Icons.Outlined.Settings, Icons.Filled.Settings)
        )
        items.forEachIndexed { index, item ->
            val isSelected = currentTab == index
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(index) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) item.third else item.second,
                        contentDescription = item.first
                    )
                },
                label = { Text(item.first, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = TiltTalkColors.TealAccentDark,
                    selectedTextColor = TiltTalkColors.NavyPrimary,
                    indicatorColor = TiltTalkColors.TealContainer,
                    unselectedIconColor = TiltTalkColors.TextSecondary,
                    unselectedTextColor = TiltTalkColors.TextSecondary
                )
            )
        }
    }
}

// =============================================================================
// SCREEN 1: HOME DASHBOARD
// =============================================================================

@Composable
fun HomeScreen(
    patientState: PatientProfileState = PatientProfileState(),
    currentCommand: CommandType = CommandType.NO_COMMAND,
    lastDetectedTime: String = "",
    isDeviceConnected: Boolean = false,
    recentItems: List<HistoryItem> = emptyList(),
    onManageConnectionClick: () -> Unit = {},
    onEditProfileClick: () -> Unit = {},
    onViewHistoryClick: () -> Unit = {},
    onSpeakAloud: (String) -> Unit = {}
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TiltTalkColors.SurfaceBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Connection Status Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(if (isDeviceConnected) TiltTalkColors.StatusConnectedGreen else TiltTalkColors.EmergencyRed)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isDeviceConnected) "CONNECTED" else "DISCONNECTED",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDeviceConnected) TiltTalkColors.TealAccentDark else TiltTalkColors.EmergencyRed
                                )
                            )
                        }
                        Text(
                            text = "Offline Node",
                            style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(TiltTalkColors.SurfaceContainerLow),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Wifi,
                                contentDescription = null,
                                tint = TiltTalkColors.NavyPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "TiltTalk ESP32 (192.168.4.1)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = "Direct Local Wi-Fi (Offline) • Last sync: Just now",
                                style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = onManageConnectionClick,
                        modifier = Modifier.align(Alignment.End),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, TiltTalkColors.BorderStrong)
                    ) {
                        Icon(Icons.Outlined.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Manage Connection", color = TiltTalkColors.NavyPrimary)
                    }
                }
            }
        }

        // 2. High-Priority Current Message Banner
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (currentCommand.isEmergency) TiltTalkColors.EmergencyRedContainer else Color.White
                ),
                border = BorderStroke(
                    width = 2.dp,
                    color = if (currentCommand.isEmergency) TiltTalkColors.EmergencyRed else TiltTalkColors.TealAccent
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.Sensors,
                                contentDescription = null,
                                tint = if (currentCommand.isEmergency) TiltTalkColors.EmergencyRed else TiltTalkColors.TealAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "CURRENT MESSAGE",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (currentCommand.isEmergency) TiltTalkColors.EmergencyRedDark else TiltTalkColors.NavyPrimary
                                )
                            )
                        }
                        Text(
                            text = lastDetectedTime,
                            style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Raw intent card
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (currentCommand.isEmergency) Color.White else TiltTalkColors.SurfaceBackground)
                            .border(1.dp, TiltTalkColors.BorderSubtle, RoundedCornerShape(12.dp))
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "RAW INTENT",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontSize = 10.sp,
                                    color = TiltTalkColors.TextSecondary
                                )
                            )
                            Text(
                                text = currentCommand.rawIntent,
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    color = if (currentCommand.isEmergency) TiltTalkColors.EmergencyRed else TiltTalkColors.NavyPrimary
                                )
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (currentCommand.isEmergency) TiltTalkColors.EmergencyRedContainer else TiltTalkColors.TealContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = currentCommand.icon,
                                contentDescription = null,
                                tint = if (currentCommand.isEmergency) TiltTalkColors.EmergencyRed else TiltTalkColors.TealAccentDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "SYNTHESIZED SPEECH OUTPUT",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontSize = 11.sp,
                            color = TiltTalkColors.TextSecondary
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "\"${currentCommand.spokenText.uppercase()}\"",
                        style = MaterialTheme.typography.displayMedium.copy(
                            color = TiltTalkColors.NavyPrimary,
                            fontWeight = FontWeight.ExtraBold
                        )
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { onSpeakAloud(currentCommand.spokenText) },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (currentCommand.isEmergency) TiltTalkColors.EmergencyRed else TiltTalkColors.TealAccent
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Outlined.VolumeUp, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Speak Aloud", fontWeight = FontWeight.Bold)
                        }
                        OutlinedIconButton(
                            onClick = { /* Clear or snooze */ },
                            modifier = Modifier.size(50.dp),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, TiltTalkColors.BorderStrong)
                        ) {
                            Icon(Icons.Outlined.Clear, contentDescription = "Dismiss", tint = TiltTalkColors.TextPrimary)
                        }
                    }
                }
            }
        }

        // 3. Clinical Patient Context
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CLINICAL PROFILE",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        TextButton(onClick = onEditProfileClick) {
                            Text("Edit Profile", color = TiltTalkColors.TealAccentDark, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(TiltTalkColors.NavyPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("EV", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = patientState.fullName,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(TiltTalkColors.TealContainer)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("Active", fontSize = 11.sp, color = TiltTalkColors.TealAccentDark, fontWeight = FontWeight.SemiBold)
                                }
                            }
                            Text(
                                text = "Age: ${patientState.calculatedAge} yrs (DOB: ${patientState.dob})",
                                style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary)
                            )
                            Text(
                                text = "${patientState.wardLocation.substringBefore(" (")} • Head-Tilt Mode",
                                style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary)
                            )
                        }
                    }
                }
            }
        }

        // 4. Recent Activity Preview
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Recent Activity", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        TextButton(onClick = onViewHistoryClick) {
                            Text("View History", color = TiltTalkColors.NavyPrimary, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val sampleRecent = recentItems.take(3).map { Triple(it.command, it.time, it.statusNote) }

                    sampleRecent.forEach { (cmd, time, detail) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (cmd.isEmergency) TiltTalkColors.EmergencyRedContainer else TiltTalkColors.SurfaceBackground)
                                .border(1.dp, if (cmd.isEmergency) TiltTalkColors.EmergencyRed else TiltTalkColors.BorderSubtle, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (cmd.isEmergency) TiltTalkColors.EmergencyRed else TiltTalkColors.TealContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = cmd.icon,
                                    contentDescription = null,
                                    tint = if (cmd.isEmergency) Color.White else TiltTalkColors.TealAccentDark,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${cmd.rawIntent} \"${cmd.spokenText.uppercase()}\"",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (cmd.isEmergency) TiltTalkColors.EmergencyRedDark else TiltTalkColors.TextPrimary
                                    )
                                )
                                Text(
                                    text = detail,
                                    style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary)
                                )
                            }
                            Text(
                                text = time,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

// =============================================================================
// SCREEN 2: DEVICE CONNECTION & DIAGNOSTICS
// =============================================================================

@Composable
fun DeviceConnectionScreen(
    isConnected: Boolean = true,
    sensorAvailable: Boolean = false,
    espIpAddress: String = "192.168.4.1",
    ssid: String = "TiltTalk",
    password: String = "TiltTalk123",
    onOpenAndroidWifiSettings: () -> Unit = {},
    onPingDevice: () -> Unit = {},
    onReconnect: () -> Unit = {}
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TiltTalkColors.SurfaceBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hardware Identity & Status
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(TiltTalkColors.SurfaceContainerLow),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Outlined.DeveloperBoard, contentDescription = null, tint = TiltTalkColors.NavyPrimary)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("TiltTalk ESP32", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text("Access Point: $ssid", style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary))
                            }
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(TiltTalkColors.TealContainer)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("Local AP", fontSize = 11.sp, color = TiltTalkColors.TealAccentDark, fontWeight = FontWeight.Bold)
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 12.dp), color = TiltTalkColors.Divider)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("IP Address:", style = MaterialTheme.typography.bodyMedium.copy(color = TiltTalkColors.TextSecondary))
                        Text(espIpAddress, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Command Endpoint:", style = MaterialTheme.typography.bodyMedium.copy(color = TiltTalkColors.TextSecondary))
                        Text("GET /data (http://$espIpAddress/data)", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = onPingDevice,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Outlined.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Ping Device")
                        }
                        Button(
                            onClick = onReconnect,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = TiltTalkColors.NavyPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Outlined.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Reconnect")
                        }
                    }
                }
            }
        }

        // Clarification: Connected without Internet is Normal
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TiltTalkColors.SurfaceContainerLow),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Info, contentDescription = null, tint = TiltTalkColors.NavyPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Connected without Internet is Normal",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TiltTalkColors.NavyPrimary)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "TiltTalk operates strictly as an offline medical hardware node. It sends raw head-tilt telemetry directly via local Wi-Fi with zero cloud dependency.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TiltTalkColors.TextPrimary)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White)
                            .border(1.dp, TiltTalkColors.BorderSubtle, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("SSID: $ssid", fontWeight = FontWeight.Bold)
                            Text("Pass: $password", fontWeight = FontWeight.SemiBold, color = TiltTalkColors.TextSecondary)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onOpenAndroidWifiSettings,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = TiltTalkColors.TealAccentDark),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Outlined.SettingsSuggest, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Open Android Wi-Fi Settings")
                    }
                }
            }
        }

        // Connection Diagnostics Grid
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Connection Diagnostics", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text("All OK", color = TiltTalkColors.StatusConnectedGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    val diagnostics = listOf(
                        Triple(Icons.Outlined.MotionPhotosOn, "Sensor Status", if (sensorAvailable) "Reported by device" else "Not reported by device")
                    )

                    diagnostics.forEach { (icon, label, value) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(icon, contentDescription = null, tint = TiltTalkColors.TealAccent, modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(value, style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary))
                                }
                            }
                            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = TiltTalkColors.StatusConnectedGreen, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

// =============================================================================
// SCREEN 3: COMMAND HISTORY
// =============================================================================

@Composable
fun CommandHistoryScreen(
    historyList: List<HistoryItem> = emptyList(),
    selectedFilterIndex: Int = 0,
    onFilterChange: (Int) -> Unit = {},
    onExportCsv: () -> Unit = {},
    onClearHistoryClick: () -> Unit = {}
) {
    var filterState by remember { mutableStateOf(selectedFilterIndex) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TiltTalkColors.SurfaceBackground)
            .padding(16.dp)
    ) {
        // Top audit banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(TiltTalkColors.SurfaceContainerLow)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.Security, contentDescription = null, tint = TiltTalkColors.NavyPrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "All events stored locally on this device. Offline audit log.",
                style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextPrimary)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Filter chips
        val filterTabs = listOf("All (42)", "Alerts & Pain (3)", "Needs & Requests (28)")
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            filterTabs.forEachIndexed { index, title ->
                val isSelected = filterState == index
                FilterChip(
                    selected = isSelected,
                    onClick = {
                        filterState = index
                        onFilterChange(index)
                    },
                    label = { Text(title, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = TiltTalkColors.NavyPrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Chronological Event Feed
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(historyList) { item ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (item.command.isEmergency) TiltTalkColors.EmergencyRedContainer else Color.White
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (item.command.isEmergency) TiltTalkColors.EmergencyRed else TiltTalkColors.BorderSubtle
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (item.command.isEmergency) TiltTalkColors.EmergencyRed else TiltTalkColors.TealContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = item.command.icon,
                                        contentDescription = null,
                                        tint = if (item.command.isEmergency) Color.White else TiltTalkColors.TealAccentDark
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = item.command.rawIntent,
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (item.command.isEmergency) TiltTalkColors.EmergencyRedDark else TiltTalkColors.NavyPrimary
                                            )
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        if (item.command.isEmergency) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(TiltTalkColors.EmergencyRed)
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text("ALERT", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                    Text(
                                        text = "\"${item.command.spokenText.uppercase()}\"",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                }
                            }
                            Text(item.time, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium))
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "• ${item.statusNote}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Bottom Actions (Strictly local export & clear)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onExportCsv,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, TiltTalkColors.BorderStrong)
            ) {
                Icon(Icons.Outlined.FileDownload, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Export CSV")
            }
            OutlinedButton(
                onClick = onClearHistoryClick,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = TiltTalkColors.EmergencyRed),
                border = BorderStroke(1.dp, TiltTalkColors.EmergencyRed)
            ) {
                Icon(Icons.Outlined.DeleteOutline, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Clear Log")
            }
        }
    }
}

// =============================================================================
// SCREEN 4: PATIENT PROFILE
// =============================================================================

@Composable
fun PatientProfileScreen(
    initialState: PatientProfileState = PatientProfileState(),
    onSaveProfile: (PatientProfileState) -> Unit = {},
    onResetDefaults: () -> Unit = {}
) {
    var state by remember { mutableStateOf(initialState) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TiltTalkColors.SurfaceBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Privacy Guarantee Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TiltTalkColors.SurfaceContainerLow),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Shield, contentDescription = null, tint = TiltTalkColors.NavyPrimary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Local Storage Only", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "Patient data remains strictly on this device and is never uploaded to the cloud or network.",
                            style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary)
                        )
                    }
                }
            }
        }

        // Patient Avatar & Core Fields
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(TiltTalkColors.NavyPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("EV", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 26.sp)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = state.fullName,
                        onValueChange = { state = state.copy(fullName = it) },
                        label = { Text("Patient Full Name") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = state.dob,
                            onValueChange = { state = state.copy(dob = it) },
                            label = { Text("Date of Birth") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(TiltTalkColors.SurfaceContainerLow)
                                .border(1.dp, TiltTalkColors.BorderSubtle, RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Column {
                                Text("Calculated Age", style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp))
                                Text("${state.calculatedAge} yrs old", fontWeight = FontWeight.Bold, color = TiltTalkColors.NavyPrimary)
                            }
                        }
                    }
                }
            }
        }

        // Clinical Ward & Emergency Contacts
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Clinical & Care Details", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = state.wardLocation,
                        onValueChange = { state = state.copy(wardLocation = it) },
                        label = { Text("Room / Ward Location") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = state.primaryNurse,
                        onValueChange = { state = state.copy(primaryNurse = it) },
                        label = { Text("Primary Attendant / Nurse") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = state.emergencyContact,
                        onValueChange = { state = state.copy(emergencyContact = it) },
                        label = { Text("Emergency Contact & Phone") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }
        }

        // Hardware Calibration & Dwell Tuning
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Sensor Calibration", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Sensitivity Level: Level ${state.sensitivityLevel} of 5", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                    Slider(
                        value = state.sensitivityLevel.toFloat(),
                        onValueChange = { state = state.copy(sensitivityLevel = it.toInt()) },
                        valueRange = 1f..5f,
                        steps = 3,
                        colors = SliderDefaults.colors(
                            thumbColor = TiltTalkColors.TealAccentDark,
                            activeTrackColor = TiltTalkColors.TealAccent
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("Dwell Selection Time", fontWeight = FontWeight.SemiBold)
                            Text("Hold duration before trigger", style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary))
                        }
                        Text("${state.dwellTimeSeconds}s", fontWeight = FontWeight.Bold, color = TiltTalkColors.NavyPrimary, fontSize = 18.sp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Audio Feedback on Dwell", fontWeight = FontWeight.Medium)
                        Switch(
                            checked = state.audioFeedbackOnDwell,
                            onCheckedChange = { state = state.copy(audioFeedbackOnDwell = it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = TiltTalkColors.TealAccentDark)
                        )
                    }
                }
            }
        }

        // Actions
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { onSaveProfile(state) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TiltTalkColors.NavyPrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Save Changes", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onResetDefaults,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, TiltTalkColors.BorderStrong)
                ) {
                    Text("Reset to Defaults", color = TiltTalkColors.TextPrimary)
                }
            }
        }
    }
}

// =============================================================================
// SCREEN 5: SETTINGS
// =============================================================================

@Composable
fun SettingsScreen(
    onNavigateToWifiSettings: () -> Unit = {},
    onManageProfile: () -> Unit = {},
    onClearAllLogs: () -> Unit = {},
    speakAloud: Boolean = true,
    onSpeakAloudChange: (Boolean) -> Unit = {},
    alertSound: Boolean = true,
    onAlertSoundChange: (Boolean) -> Unit = {},
    vibration: Boolean = true,
    onVibrationChange: (Boolean) -> Unit = {}
) {
    var selectedLanguage by remember { mutableStateOf("English (United States)") }
    var fullScreenEmergencyBanner by remember { mutableStateOf(true) }
    var speechRate by remember { mutableStateOf(1.0f) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TiltTalkColors.SurfaceBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section: Audio & Speech Synthesis
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "AUDIO & SPEECH SYNTHESIS (TTS)",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TiltTalkColors.NavyPrimary)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Speak Messages Aloud", fontWeight = FontWeight.SemiBold)
                            Text("Uses Android Text-to-Speech to vocalize commands", style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary))
                        }
                        Switch(
                            checked = speakAloud,
                            onCheckedChange = onSpeakAloudChange,
                            colors = SwitchDefaults.colors(checkedThumbColor = TiltTalkColors.TealAccentDark)
                        )
                    }

                    Divider(modifier = Modifier.padding(vertical = 10.dp), color = TiltTalkColors.Divider)

                    Text("Spoken Language: $selectedLanguage", fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(6.dp))

                    // Tamil voice pack verification notice
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(TiltTalkColors.SurfaceContainerLow)
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Check, contentDescription = null, tint = TiltTalkColors.TealAccentDark, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Tamil (Offline voice pack installed)", fontSize = 12.sp, color = TiltTalkColors.NavyPrimary)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Speech Rate: ${String.format("%.1fx", speechRate)}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                    Slider(
                        value = speechRate,
                        onValueChange = { speechRate = it },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = TiltTalkColors.NavyPrimary)
                    )
                }
            }
        }

        // Section: Alerts & Notifications
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "ALERTS & NOTIFICATIONS",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TiltTalkColors.NavyPrimary)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Alert Sound on Emergency", fontWeight = FontWeight.SemiBold)
                            Text("Loud chime for PAIN and EMERGENCY", style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary))
                        }
                        Switch(
                            checked = alertSound,
                            onCheckedChange = onAlertSoundChange,
                            colors = SwitchDefaults.colors(checkedThumbColor = TiltTalkColors.EmergencyRed)
                        )
                    }

                    Divider(modifier = Modifier.padding(vertical = 8.dp), color = TiltTalkColors.Divider)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Haptic / Vibration Feedback", fontWeight = FontWeight.SemiBold)
                            Text("Vibrate on every received command", style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary))
                        }
                        Switch(
                            checked = vibration,
                            onCheckedChange = onVibrationChange,
                            colors = SwitchDefaults.colors(checkedThumbColor = TiltTalkColors.TealAccentDark)
                        )
                    }

                    Divider(modifier = Modifier.padding(vertical = 8.dp), color = TiltTalkColors.Divider)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Full Screen Emergency Banner", fontWeight = FontWeight.SemiBold)
                            Text("Max-priority takeover for urgent care calls", style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary))
                        }
                        Switch(
                            checked = fullScreenEmergencyBanner,
                            onCheckedChange = { fullScreenEmergencyBanner = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = TiltTalkColors.TealAccentDark)
                        )
                    }
                }
            }
        }

        // Section: Hardware & Connection
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "HARDWARE & CONNECTION",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TiltTalkColors.NavyPrimary)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("ESP32 Node IP", style = MaterialTheme.typography.bodyMedium)
                        Text("192.168.4.1", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Polling Interval", style = MaterialTheme.typography.bodyMedium)
                        Text("750 ms", fontWeight = FontWeight.SemiBold, color = TiltTalkColors.TealAccentDark)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = onNavigateToWifiSettings,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Manage Wi-Fi & Pairing", color = TiltTalkColors.NavyPrimary)
                    }
                }
            }
        }

        // Section: Data & Privacy
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "DATA & PRIVACY",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = TiltTalkColors.NavyPrimary)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Local Command History", fontWeight = FontWeight.Medium)
                        OutlinedButton(
                            onClick = onClearAllLogs,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TiltTalkColors.EmergencyRed),
                            border = BorderStroke(1.dp, TiltTalkColors.EmergencyRed),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Clear All Logs", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "100% Offline. Zero telemetry, zero cloud tracking, zero external APIs.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary)
                    )
                }
            }
        }

        // About & Version
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("TiltTalk Assistive Technologies", fontWeight = FontWeight.Bold, color = TiltTalkColors.NavyPrimary)
                Text("0.1.0-prototype", style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary))
                Text("Requires the patched TiltTalk firmware", style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TealAccentDark))
            }
        }
    }
}

// =============================================================================
// SCREEN 6: EMERGENCY ALERT OVERLAY
// =============================================================================

@Composable
fun EmergencyAlertOverlay(
    patientState: PatientProfileState = PatientProfileState(),
    emergencyCommand: CommandType = CommandType.EMERGENCY,
    triggerTime: String = "",
    onAcknowledgeAndSilence: () -> Unit = {},
    onLogNoteAndReturn: () -> Unit = {}
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFF0F0))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Critical Alert Banner Header
            Card(
                colors = CardDefaults.cardColors(containerColor = TiltTalkColors.EmergencyRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Warning, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("CRITICAL ALERT - ASSISTANCE REQUIRED", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                        Text("Alert shown on this phone", style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.9f)))
                    }
                }
            }

            // Main Emergency Intent Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(2.dp, TiltTalkColors.EmergencyRed),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(TiltTalkColors.EmergencyRedContainer)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("HIGH PRIORITY #EV-0842", color = TiltTalkColors.EmergencyRed, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = emergencyCommand.rawIntent,
                        style = MaterialTheme.typography.displayMedium.copy(
                            color = TiltTalkColors.EmergencyRed,
                            fontWeight = FontWeight.ExtraBold
                        )
                    )
                    Text(
                        text = "Assistance required.",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            color = TiltTalkColors.EmergencyRedDark,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(TiltTalkColors.SurfaceContainerLow)
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Triggered via Head-Tilt MPU6050", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Dwell Hold Duration: 1.5 seconds (Left-Tilt)", fontSize = 12.sp, color = TiltTalkColors.TextSecondary)
                            Text("Detected Timestamp: $triggerTime", fontSize = 12.sp, color = TiltTalkColors.TextSecondary)
                            Text("Mesh Channel: Offline Direct Wi-Fi (192.168.4.1)", fontSize = 12.sp, color = TiltTalkColors.TealAccentDark)
                        }
                    }
                }
            }

            // Patient & Ward Context
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Patient & Ward Context", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Patient: ${patientState.fullName} (${patientState.calculatedAge} yrs)", fontWeight = FontWeight.SemiBold)
                    Text("Location: ${patientState.wardLocation}", color = TiltTalkColors.NavyPrimary, fontWeight = FontWeight.Bold)
                    Text("Primary Nurse: ${patientState.primaryNurse}", style = MaterialTheme.typography.bodySmall)
                    Text("Contact: ${patientState.emergencyContact}", style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TealAccentDark))
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Action Buttons
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onAcknowledgeAndSilence,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TiltTalkColors.EmergencyRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Outlined.NotificationsOff, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Acknowledge & Silence Local Chime", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }

                OutlinedButton(
                    onClick = onLogNoteAndReturn,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, TiltTalkColors.BorderStrong)
                ) {
                    Icon(Icons.Outlined.EditNote, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Log Note & Return to Dashboard", color = TiltTalkColors.NavyPrimary)
                }

                Text(
                    "Acknowledging does not delete this event from the local history log.",
                    style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

// =============================================================================
// SCREEN 7: FIRST-LAUNCH ONBOARDING
// =============================================================================

@Composable
fun OnboardingScreen(
    onConnectDeviceClick: () -> Unit = {},
    onSkipToDemoMode: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        // Brand Icon / Wordmark
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(TiltTalkColors.SurfaceContainerLow),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.RecordVoiceOver,
                contentDescription = null,
                tint = TiltTalkColors.NavyPrimary,
                modifier = Modifier.size(44.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "TiltTalk",
            style = MaterialTheme.typography.displayMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                color = TiltTalkColors.NavyPrimary
            )
        )
        Text(
            text = "Assistive Patient Communication",
            style = MaterialTheme.typography.bodyLarge.copy(color = TiltTalkColors.TextSecondary)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(TiltTalkColors.TealContainer)
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(
                text = "• 100% OFFLINE • PRIVATE & LOCAL",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TiltTalkColors.TealAccentDark
                )
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Feature cards
        val features = listOf(
            Triple(Icons.Outlined.CompareArrows, "Direct ESP32 Sensing", "Detects intentional micro head tilts in real time and shows them to caregivers on this phone."),
            Triple(Icons.Outlined.Wifi, "Local Direct Wi-Fi", "Connects straight to the headband's self-hosted AP. No internet connection, routers, or cloud accounts required."),
            Triple(Icons.Outlined.Shield, "Privacy by Design", "All patient profiles, calibration maps, and communication records stay solely in local Android sandboxed memory.")
        )

        features.forEach { (icon, title, desc) ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TiltTalkColors.SurfaceBackground),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(TiltTalkColors.SurfaceContainerLow),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = TiltTalkColors.NavyPrimary)
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(title, fontWeight = FontWeight.Bold, color = TiltTalkColors.NavyPrimary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(desc, style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onConnectDeviceClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = TiltTalkColors.NavyPrimary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Outlined.Sensors, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Connect TiltTalk Device", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(10.dp))

        TextButton(onClick = onSkipToDemoMode) {
            Text("Skip profile setup", color = TiltTalkColors.TealAccentDark, fontWeight = FontWeight.SemiBold)
        }
    }
}

// =============================================================================
// SCREEN 8: SYSTEM FEEDBACK & DIALOG STATES
// =============================================================================

@Composable
fun SystemFeedbackAndDialogsScreen(
    onRetryHandshake: () -> Unit = {},
    onOpenWifiSettings: () -> Unit = {},
    onConfirmClearLogs: () -> Unit = {},
    onDismissClearLogs: () -> Unit = {}
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TiltTalkColors.SurfaceBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("CLINICAL FEEDBACK PATTERNS", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
        }

        // Pattern 1: Inline Profile Update Snackbar
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = TiltTalkColors.StatusConnectedGreen)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Patient profile updated locally", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Dwell speed calibrated to 1.2s", style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextSecondary))
                    }
                    IconButton(onClick = {}) {
                        Icon(Icons.Outlined.Close, contentDescription = "Close", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // Pattern 2: Destructive Clear Confirmation Dialog
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(TiltTalkColors.EmergencyRedContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Outlined.DeleteOutline, contentDescription = null, tint = TiltTalkColors.EmergencyRed)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Clear Local History?", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Action irreversible", style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.EmergencyRed))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        "Are you sure you want to delete all 42 recorded communication logs? This action is permanent and cannot be undone.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TiltTalkColors.TextSecondary)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = onDismissClearLogs,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Cancel", color = TiltTalkColors.TextPrimary)
                        }
                        Button(
                            onClick = onConfirmClearLogs,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = TiltTalkColors.EmergencyRed),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Clear All Logs")
                        }
                    }
                }
            }
        }

        // Pattern 3: Missing Voice Pack Bottom Sheet
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, TiltTalkColors.BorderSubtle),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Offline Speech Pack Status", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(TiltTalkColors.SurfaceContainerLow)
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Tamil (தமிழ்) Voice Pack", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Icon(Icons.Outlined.Warning, contentDescription = null, tint = TiltTalkColors.StatusWarningAmber)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {},
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = TiltTalkColors.NavyPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Outlined.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Install Voice via Android Settings")
                    }
                }
            }
        }

        // Pattern 4: Device Disconnected Alert Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TiltTalkColors.EmergencyRedContainer),
                border = BorderStroke(1.dp, TiltTalkColors.EmergencyRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.WifiOff, contentDescription = null, tint = TiltTalkColors.EmergencyRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "TiltTalk Device Disconnected",
                            fontWeight = FontWeight.Bold,
                            color = TiltTalkColors.EmergencyRedDark,
                            fontSize = 15.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Lost connection to ESP32 at 192.168.4.1. Check the last contact time on the Connection screen. Ensure the patient node is powered on and within local Wi-Fi range.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TiltTalkColors.TextPrimary)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onRetryHandshake,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = TiltTalkColors.TealAccentDark),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Retry Handshake")
                        }
                        OutlinedButton(
                            onClick = onOpenWifiSettings,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Wi-Fi Settings")
                        }
                    }
                }
            }
        }
    }
}
