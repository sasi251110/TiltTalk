package com.tilttalk.app.network

import android.net.Network
import com.tilttalk.app.data.FetchResult
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL

class TiltTalkClient(
    private val url: URL = URL("http://192.168.4.1/data"),
    private val timeoutMs: Int = 1500,
) {
    /** Blocking. Call from Dispatchers.IO. */
    fun fetch(network: Network?): FetchResult {
        val connection = try {
            val raw = if (network != null) network.openConnection(url) else url.openConnection()
            raw as HttpURLConnection
        } catch (e: IOException) {
            return FetchResult.Unreachable
        }

        return try {
            connection.requestMethod = "GET"
            connection.connectTimeout = timeoutMs
            connection.readTimeout = timeoutMs
            connection.useCaches = false

            val code = connection.responseCode
            if (code !in 200..299) {
                FetchResult.HttpError(code)
            } else {
                FetchResult.Body(connection.inputStream.bufferedReader().use { it.readText() })
            }
        } catch (e: SocketTimeoutException) {
            FetchResult.Timeout
        } catch (e: IOException) {
            FetchResult.Unreachable
        } finally {
            connection.disconnect()
        }
    }
}
