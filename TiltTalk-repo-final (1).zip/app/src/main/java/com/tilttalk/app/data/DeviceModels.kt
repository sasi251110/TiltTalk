package com.tilttalk.app.data

enum class DeviceCommand(val wire: String) {
    HELP("HELP"),
    WATER("WATER"),
    FOOD("FOOD"),
    RESTROOM("RESTROOM"),
    YES("YES"),
    NO("NO"),
    CALL("CALL"),
    PAIN("PAIN"),
    EMERGENCY("EMERGENCY"),
    STOP("STOP"),
    NO_COMMAND("NO COMMAND");

    val isEmergency: Boolean get() = this == EMERGENCY

    companion object {
        fun fromWire(value: String?): DeviceCommand? = entries.firstOrNull { it.wire == value }
    }
}

data class DeviceStatus(
    val device: String?,
    val rawCommand: String,
    val command: DeviceCommand?,
    val rawLastCommand: String?,
    val seq: Long?,
    val pitch: Double?,
    val roll: Double?,
    val uptimeMs: Long?,
    val timestampMs: Long?,
    val locked: Boolean?,
    val mpuAvailable: Boolean?,
)

sealed interface ParseResult {
    data class Ok(val status: DeviceStatus) : ParseResult
    data class Malformed(val reason: String) : ParseResult
}

sealed interface FetchResult {
    data class Body(val text: String) : FetchResult
    data class HttpError(val code: Int) : FetchResult
    data object Timeout : FetchResult
    data object Unreachable : FetchResult
}
