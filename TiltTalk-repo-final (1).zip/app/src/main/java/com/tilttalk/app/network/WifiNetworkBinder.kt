package com.tilttalk.app.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.util.Log

/**
 * Requests a Wi-Fi network that does not require internet access, so requests to
 * the TiltTalk access point are routed over Wi-Fi instead of mobile data.
 *
 * If the phone has several Wi-Fi networks, Android may pick a different one. The
 * fetch then fails and the UI reports the device as unreachable.
 */
class WifiNetworkBinder(context: Context) {
    private val connectivity = context.getSystemService(ConnectivityManager::class.java)

    @Volatile
    var network: Network? = null
        private set

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            this@WifiNetworkBinder.network = network
        }

        override fun onLost(network: Network) {
            if (this@WifiNetworkBinder.network == network) {
                this@WifiNetworkBinder.network = null
            }
        }
    }

    private val request = NetworkRequest.Builder()
        .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
        .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        .build()

    fun start() {
        try {
            connectivity.requestNetwork(request, callback)
        } catch (e: SecurityException) {
            Log.w(TAG, "Wi-Fi network request denied", e)
        }
    }

    fun stop() {
        runCatching { connectivity.unregisterNetworkCallback(callback) }
    }

    private companion object {
        const val TAG = "WifiNetworkBinder"
    }
}
