package com.tilttalk.app.domain

import com.tilttalk.app.data.DeviceCommand
import com.tilttalk.app.data.DeviceStatus

data class CommandEvent(
    val command: DeviceCommand,
    val rawCommand: String,
    val detectedAtMs: Long,
    val seq: Long?,
)

/**
 * Converts polled snapshots into discrete command events.
 *
 * With firmware that reports `seq`: an event is emitted whenever `seq` increases,
 * using `lastCommand` as the command. This detects repeats of the same command.
 *
 * Without `seq`: an event is emitted when `command` changes to a real command.
 * Repeats are only detected if NO COMMAND was seen between polls.
 *
 * The first snapshot only sets a baseline, so a command already active when the
 * app starts is not recorded as a new event.
 */
class CommandEventTracker {
    private var baselined = false
    private var lastSeq: Long? = null
    private var lastCommand: DeviceCommand? = null

    fun onStatus(status: DeviceStatus, nowMs: Long): CommandEvent? {
        if (status.mpuAvailable == false) return null
        val seq = status.seq
        return if (seq != null) onSequenced(status, seq, nowMs) else onTransition(status, nowMs)
    }

    private fun onSequenced(status: DeviceStatus, seq: Long, nowMs: Long): CommandEvent? {
        val previous = lastSeq
        lastSeq = seq
        if (!baselined) {
            baselined = true
            return null
        }
        if (previous == null || seq <= previous) return null

        val raw = status.rawLastCommand ?: return null
        val command = DeviceCommand.fromWire(raw) ?: return null
        if (command == DeviceCommand.NO_COMMAND) return null
        return CommandEvent(command, raw, nowMs, seq)
    }

    private fun onTransition(status: DeviceStatus, nowMs: Long): CommandEvent? {
        val command = status.command
        val previous = lastCommand
        lastCommand = command
        if (!baselined) {
            baselined = true
            return null
        }
        if (command == null || command == DeviceCommand.NO_COMMAND || command == previous) return null
        return CommandEvent(command, status.rawCommand, nowMs, seq = null)
    }
}
