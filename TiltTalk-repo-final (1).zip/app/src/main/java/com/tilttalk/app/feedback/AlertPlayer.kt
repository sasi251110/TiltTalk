package com.tilttalk.app.feedback

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class AlertPlayer(context: Context) {

    private val vibrator: Vibrator? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Vibrator::class.java)
        }

    private val tone: ToneGenerator? = runCatching {
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
    }.getOrNull()

    fun play(emergency: Boolean, sound: Boolean, vibrate: Boolean) {
        val durationMs = if (emergency) 800L else 250L

        val toneGenerator = tone
        if (sound && toneGenerator != null) {
            val toneType = if (emergency) {
                ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD
            } else {
                ToneGenerator.TONE_PROP_BEEP
            }
            toneGenerator.startTone(toneType, durationMs.toInt())
        }

        val device = vibrator
        if (vibrate && device != null && device.hasVibrator()) {
            device.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    fun release() {
        tone?.release()
    }
}
