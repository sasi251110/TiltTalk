package com.tilttalk.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.tilttalk.app.ui.LiveViewModel
import com.tilttalk.app.ui.TiltTalkApp
import com.tilttalk.app.ui.theme.TiltTalkTheme

class MainActivity : ComponentActivity() {

    private val viewModel: LiveViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TiltTalkTheme {
                val state by viewModel.state.collectAsState()
                TiltTalkApp(
                    state = state,
                    onRetry = viewModel::retry,
                    onOpenWifiSettings = { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) },
                    onAcknowledgeEmergency = viewModel::acknowledgeEmergency,
                    onClearHistory = viewModel::clearHistory,
                    onSaveProfile = viewModel::saveProfile,
                    onFeedbackChange = viewModel::updateFeedback,
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        viewModel.setForeground(true)
    }

    override fun onStop() {
        viewModel.setForeground(false)
        super.onStop()
    }
}
