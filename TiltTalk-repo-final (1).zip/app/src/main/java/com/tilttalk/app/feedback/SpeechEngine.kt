package com.tilttalk.app.feedback

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class SpeechStatus { INITIALIZING, READY, LANGUAGE_UNAVAILABLE, FAILED }

/**
 * Wraps Android TextToSpeech. Speech availability depends on the device's installed
 * voice data; the app never downloads voices or calls an online service itself.
 */
class SpeechEngine(context: Context) {

    private val _status = MutableStateFlow(SpeechStatus.INITIALIZING)
    val status: StateFlow<SpeechStatus> = _status.asStateFlow()

    private var ready = false

    private val tts = TextToSpeech(context.applicationContext) { code ->
        ready = code == TextToSpeech.SUCCESS
        _status.value = if (ready) SpeechStatus.READY else SpeechStatus.FAILED
    }

    fun speak(text: String, locale: Locale) {
        if (!ready) return
        val result = tts.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            _status.value = SpeechStatus.LANGUAGE_UNAVAILABLE
            return
        }
        _status.value = SpeechStatus.READY
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tilttalk-${System.nanoTime()}")
    }

    fun stop() {
        if (ready) tts.stop()
    }

    fun shutdown() {
        ready = false
        tts.shutdown()
    }
}
