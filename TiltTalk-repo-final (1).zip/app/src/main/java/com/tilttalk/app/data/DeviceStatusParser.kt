package com.tilttalk.app.data

import org.json.JSONException
import org.json.JSONObject

object DeviceStatusParser {

    fun parse(body: String): ParseResult {
        val json = try {
            JSONObject(body)
        } catch (e: JSONException) {
            return ParseResult.Malformed("Response is not valid JSON")
        }

        val rawCommand = (json.opt("command") as? String)
            ?: return ParseResult.Malformed("Missing command field")

        return ParseResult.Ok(
            DeviceStatus(
                device = json.opt("device") as? String,
                rawCommand = rawCommand,
                command = DeviceCommand.fromWire(rawCommand),
                rawLastCommand = json.opt("lastCommand") as? String,
                seq = json.number("seq")?.toLong(),
                pitch = json.number("pitch")?.toDouble(),
                roll = json.number("roll")?.toDouble(),
                uptimeMs = json.number("uptime")?.toLong(),
                timestampMs = json.number("timestamp")?.toLong(),
                locked = json.opt("locked") as? Boolean,
                mpuAvailable = json.opt("mpuAvailable") as? Boolean,
            )
        )
    }

    private fun JSONObject.number(key: String): Number? = opt(key) as? Number
}
