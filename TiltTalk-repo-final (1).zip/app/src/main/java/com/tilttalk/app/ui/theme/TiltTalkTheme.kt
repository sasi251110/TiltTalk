package com.tilttalk.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// =============================================================================
// 1. BRAND & CLINICAL COLOR PALETTE
// =============================================================================

object TiltTalkColors {
    // Primary Structural Brand
    val NavyPrimary = Color(0xFF173B57)
    val NavyPrimaryDark = Color(0xFF0F2639)
    val NavyPrimaryLight = Color(0xFF265073)

    // Secondary Accent & Connected State
    val TealAccent = Color(0xFF168C88)
    val TealAccentDark = Color(0xFF106865)
    val TealAccentLight = Color(0xFF28B4AF)
    val TealContainer = Color(0xFFE0F3F2)
    val OnTealContainer = Color(0xFF094442)

    // Critical Emergency & Alerts (Strictly reserved for Medical/Pain)
    val EmergencyRed = Color(0xFFD64545)
    val EmergencyRedDark = Color(0xFFA83232)
    val EmergencyRedContainer = Color(0xFFFBE8E8)
    val OnEmergencyRed = Color(0xFFFFFFFF)

    // Surfaces & Backgrounds
    val SurfaceBackground = Color(0xFFF7F8FA)
    val SurfaceWhite = Color(0xFFFFFFFF)
    val SurfaceCard = Color(0xFFFFFFFF)
    val SurfaceContainerLow = Color(0xFFEEF4FF)
    val SurfaceContainerHigh = Color(0xFFE4EBF5)

    // Text & Content Hierarchy
    val TextPrimary = Color(0xFF18212B)
    val TextSecondary = Color(0xFF667085)
    val TextMuted = Color(0xFF98A2B3)
    val TextInverse = Color(0xFFFFFFFF)

    // Outlines & Dividers
    val BorderSubtle = Color(0xFFE1E6EB)
    val BorderStrong = Color(0xFFCBD5E1)
    val Divider = Color(0xFFEEF2F6)

    // Hardware Telemetry & Status Badges
    val StatusConnectedGreen = Color(0xFF10B981)
    val StatusConnectedGreenContainer = Color(0xFFECFDF5)
    val StatusWarningAmber = Color(0xFFF59E0B)
    val StatusWarningContainer = Color(0xFFFEF3C7)
}

// Material 3 Light Color Scheme Mapping
val TiltTalkLightColorScheme: ColorScheme = lightColorScheme(
    primary = TiltTalkColors.NavyPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD8E4EE),
    onPrimaryContainer = TiltTalkColors.NavyPrimaryDark,
    secondary = TiltTalkColors.TealAccent,
    onSecondary = Color.White,
    secondaryContainer = TiltTalkColors.TealContainer,
    onSecondaryContainer = TiltTalkColors.OnTealContainer,
    tertiary = TiltTalkColors.TealAccentDark,
    onTertiary = Color.White,
    error = TiltTalkColors.EmergencyRed,
    onError = Color.White,
    errorContainer = TiltTalkColors.EmergencyRedContainer,
    onErrorContainer = TiltTalkColors.EmergencyRedDark,
    background = TiltTalkColors.SurfaceBackground,
    onBackground = TiltTalkColors.TextPrimary,
    surface = TiltTalkColors.SurfaceWhite,
    onSurface = TiltTalkColors.TextPrimary,
    surfaceVariant = TiltTalkColors.SurfaceContainerLow,
    onSurfaceVariant = TiltTalkColors.TextSecondary,
    outline = TiltTalkColors.BorderSubtle,
    outlineVariant = TiltTalkColors.Divider
)

// Material 3 Dark Color Scheme Mapping (High-Contrast Bedside Night Mode)
val TiltTalkDarkColorScheme: ColorScheme = darkColorScheme(
    primary = Color(0xFF8AB4F8),
    onPrimary = Color(0xFF0A223B),
    primaryContainer = TiltTalkColors.NavyPrimaryDark,
    onPrimaryContainer = Color(0xFFD8E4EE),
    secondary = TiltTalkColors.TealAccentLight,
    onSecondary = Color(0xFF003735),
    secondaryContainer = TiltTalkColors.TealAccentDark,
    onSecondaryContainer = TiltTalkColors.TealContainer,
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410),
    errorContainer = Color(0xFF8C1D18),
    onErrorContainer = Color(0xFFF9DEDC),
    background = Color(0xFF101418),
    onBackground = Color(0xFFE1E2E8),
    surface = Color(0xFF181C20),
    onSurface = Color(0xFFE1E2E8),
    surfaceVariant = Color(0xFF222830),
    onSurfaceVariant = Color(0xFFC4C7D0),
    outline = Color(0xFF3B4450),
    outlineVariant = Color(0xFF28303A)
)

// =============================================================================
// 2. EXTENDED CLINICAL COLOR TOKENS
// =============================================================================

@Immutable
data class ExtendedClinicalColors(
    val emergencyBanner: Color,
    val onEmergencyBanner: Color,
    val emergencyBorder: Color,
    val emergencyCardBg: Color,
    val hardwareConnectedBadge: Color,
    val hardwareConnectedText: Color,
    val hardwareDisconnectedBadge: Color,
    val hardwareDisconnectedText: Color,
    val localStorageCardBorder: Color,
    val commandCardBorder: Color
)

val LocalExtendedClinicalColors = staticCompositionLocalOf {
    ExtendedClinicalColors(
        emergencyBanner = TiltTalkColors.EmergencyRed,
        onEmergencyBanner = Color.White,
        emergencyBorder = TiltTalkColors.EmergencyRed,
        emergencyCardBg = TiltTalkColors.EmergencyRedContainer,
        hardwareConnectedBadge = TiltTalkColors.StatusConnectedGreenContainer,
        hardwareConnectedText = Color(0xFF065F46),
        hardwareDisconnectedBadge = Color(0xFFFEE2E2),
        hardwareDisconnectedText = Color(0xFF991B1B),
        localStorageCardBorder = TiltTalkColors.BorderSubtle,
        commandCardBorder = TiltTalkColors.TealAccent
    )
}

// =============================================================================
// 3. 8-DP GRID SYSTEM & SPACING TOKENS
// =============================================================================

@Immutable
data class TiltTalkSpacing(
    val space2: Dp = 2.dp,
    val space4: Dp = 4.dp,
    val space8: Dp = 8.dp,      // Base unit
    val space12: Dp = 12.dp,
    val space16: Dp = 16.dp,    // Standard screen edge margin
    val space20: Dp = 20.dp,
    val space24: Dp = 24.dp,    // Section separation
    val space32: Dp = 32.dp,
    val space40: Dp = 40.dp,
    val space48: Dp = 48.dp,    // Minimum touch target
    val space56: Dp = 56.dp,    // Action button height
    val space64: Dp = 64.dp     // Bottom nav bar height
)

val LocalSpacing = staticCompositionLocalOf { TiltTalkSpacing() }

// =============================================================================
// 4. SHAPES (12-16 DP CORNER RADII)
// =============================================================================

val TiltTalkShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),    // Default card shape
    large = RoundedCornerShape(16.dp),     // Prominent communication card
    extraLarge = RoundedCornerShape(24.dp) // Action buttons & bottom sheets
)

// =============================================================================
// 5. TYPOGRAPHY SYSTEM (ROBOTO / NATIVE ANDROID)
// =============================================================================

val TiltTalkTypography = Typography(
    // Large Current Patient Message Headline
    displayMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 34.sp,
        letterSpacing = (-0.5).sp,
        color = TiltTalkColors.NavyPrimary
    ),
    // Raw Telemetry / Intent Title (e.g. WATER, PAIN, EMERGENCY)
    headlineLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 24.sp,
        lineHeight = 30.sp,
        letterSpacing = 0.5.sp,
        color = TiltTalkColors.TealAccent
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 26.sp,
        color = TiltTalkColors.TextPrimary
    ),
    // Section Headers
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 24.sp,
        color = TiltTalkColors.TextPrimary
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        color = TiltTalkColors.TextPrimary
    ),
    // Section Eyebrows / Uppercase Labels (e.g. "CURRENT MESSAGE", "RAW INTENT")
    labelMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        lineHeight = 16.sp,
        letterSpacing = 1.2.sp,
        color = TiltTalkColors.TextSecondary
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp
    ),
    // Primary Body Text
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        color = TiltTalkColors.TextPrimary
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        color = TiltTalkColors.TextSecondary
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        color = TiltTalkColors.TextMuted
    )
)

// =============================================================================
// 6. MAIN THEME COMPOSABLE
// =============================================================================

@Composable
fun TiltTalkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) TiltTalkDarkColorScheme else TiltTalkLightColorScheme
    val clinicalColors = LocalExtendedClinicalColors.current
    val spacing = LocalSpacing.current

    androidx.compose.runtime.CompositionLocalProvider(
        LocalExtendedClinicalColors provides clinicalColors,
        LocalSpacing provides spacing
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = TiltTalkTypography,
            shapes = TiltTalkShapes,
            content = content
        )
    }
}

// Accessor for custom theme tokens
object TiltTalkTheme {
    val clinicalColors: ExtendedClinicalColors
        @Composable
        @ReadOnlyComposable
        get() = LocalExtendedClinicalColors.current

    val spacing: TiltTalkSpacing
        @Composable
        @ReadOnlyComposable
        get() = LocalSpacing.current
}
