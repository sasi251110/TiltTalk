package com.tilttalk.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.tilttalk.app.ui.screens.CommandHistoryScreen
import com.tilttalk.app.ui.screens.CommandType
import com.tilttalk.app.ui.screens.DeviceConnectionScreen
import com.tilttalk.app.ui.screens.EmergencyAlertOverlay
import com.tilttalk.app.ui.screens.HomeScreen
import com.tilttalk.app.ui.screens.PatientProfileScreen
import com.tilttalk.app.ui.screens.PatientProfileState
import com.tilttalk.app.ui.screens.SettingsScreen
import com.tilttalk.app.ui.screens.TiltTalkBottomBar
import com.tilttalk.app.ui.screens.TiltTalkTopAppBar
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class SubScreen { NONE, CONNECTION, PROFILE }

private const val TAB_HOME = 0
private const val TAB_HISTORY = 1
private const val TAB_SETTINGS = 2

@Composable
fun TiltTalkApp(
    state: LiveState,
    onRetry: () -> Unit,
    onOpenWifiSettings: () -> Unit,
    onAcknowledgeEmergency: () -> Unit,
    onClearHistory: () -> Unit,
    onSaveProfile: (PatientProfileState) -> Unit,
    onFeedbackChange: (FeedbackSettings) -> Unit,
) {
    var tab by rememberSaveable { mutableIntStateOf(TAB_HOME) }
    var subScreen by rememberSaveable { mutableStateOf(SubScreen.NONE) }

    val connected = state.link == LinkState.CONNECTED
    // The last recognized command; the Home screen also receives connection state.
    val current = state.current ?: CommandType.NO_COMMAND
    val detectedTime = state.currentDetectedMs?.let(::formatClock).orEmpty()
    val feedback = state.feedback

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                TiltTalkTopAppBar(
                    title = "TiltTalk",
                    showBackButton = subScreen != SubScreen.NONE,
                    onBackClick = { subScreen = SubScreen.NONE },
                    showSettingsAction = subScreen == SubScreen.NONE,
                    onSettingsClick = { tab = TAB_SETTINGS },
                )
            },
            bottomBar = {
                if (subScreen == SubScreen.NONE) {
                    TiltTalkBottomBar(currentTab = tab, onTabSelected = { tab = it })
                }
            },
        ) { innerPadding ->
            Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
                when (subScreen) {
                    SubScreen.CONNECTION -> DeviceConnectionScreen(
                        isConnected = connected,
                        sensorAvailable = connected && !state.sensorFault,
                        onOpenAndroidWifiSettings = onOpenWifiSettings,
                        onPingDevice = onRetry,
                        onReconnect = onRetry,
                    )

                    SubScreen.PROFILE -> PatientProfileScreen(
                        initialState = state.profile,
                        onSaveProfile = onSaveProfile,
                        onResetDefaults = { onSaveProfile(PatientProfileState()) },
                    )

                    SubScreen.NONE -> when (tab) {
                        TAB_HOME -> HomeScreen(
                            patientState = state.profile,
                            currentCommand = current,
                            lastDetectedTime = detectedTime,
                            isDeviceConnected = connected,
                            recentItems = state.history,
                            onManageConnectionClick = { subScreen = SubScreen.CONNECTION },
                            onEditProfileClick = { subScreen = SubScreen.PROFILE },
                            onViewHistoryClick = { tab = TAB_HISTORY },
                            onSpeakAloud = {},
                        )

                        TAB_HISTORY -> CommandHistoryScreen(
                            historyList = state.history,
                            onClearHistoryClick = onClearHistory,
                        )

                        else -> SettingsScreen(
                            onNavigateToWifiSettings = onOpenWifiSettings,
                            onManageProfile = { subScreen = SubScreen.PROFILE },
                            onClearAllLogs = onClearHistory,
                            speakAloud = feedback.speechEnabled,
                            onSpeakAloudChange = { onFeedbackChange(feedback.copy(speechEnabled = it)) },
                            alertSound = feedback.soundEnabled,
                            onAlertSoundChange = { onFeedbackChange(feedback.copy(soundEnabled = it)) },
                            vibration = feedback.vibrationEnabled,
                            onVibrationChange = { onFeedbackChange(feedback.copy(vibrationEnabled = it)) },
                        )
                    }
                }
            }
        }

        if (state.emergencyPending) {
            EmergencyAlertOverlay(
                patientState = state.profile,
                emergencyCommand = CommandType.EMERGENCY,
                triggerTime = detectedTime,
                onAcknowledgeAndSilence = onAcknowledgeEmergency,
                onLogNoteAndReturn = {
                    onAcknowledgeEmergency()
                    subScreen = SubScreen.NONE
                    tab = TAB_HOME
                },
            )
        }
    }
}

private fun formatClock(ms: Long): String =
    SimpleDateFormat("hh:mm:ss a", Locale.US).format(Date(ms))
