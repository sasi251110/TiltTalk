package com.tilttalk.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tilttalk.app.data.DeviceCommand
import com.tilttalk.app.data.DeviceStatusParser
import com.tilttalk.app.data.FetchResult
import com.tilttalk.app.data.ParseResult
import com.tilttalk.app.domain.Age
import com.tilttalk.app.domain.CommandEvent
import com.tilttalk.app.domain.CommandEventTracker
import com.tilttalk.app.feedback.AlertPlayer
import com.tilttalk.app.feedback.SpeechEngine
import com.tilttalk.app.feedback.SpeechStatus
import com.tilttalk.app.network.TiltTalkClient
import com.tilttalk.app.network.WifiNetworkBinder
import com.tilttalk.app.ui.screens.CommandType
import com.tilttalk.app.ui.screens.HistoryItem
import com.tilttalk.app.ui.screens.PatientProfileState
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class LinkState { CONNECTING, CONNECTED, UNREACHABLE, TIMEOUT, ERROR }

data class FeedbackSettings(
    val speechEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val speechLocale: Locale = Locale.forLanguageTag("en-US"),
)

data class LiveState(
    val link: LinkState = LinkState.CONNECTING,
    val lastError: String? = null,
    val lastSuccessMs: Long? = null,
    val current: CommandType? = null,
    val currentDetectedMs: Long? = null,
    val sensorFault: Boolean = false,
    val emergencyPending: Boolean = false,
    val history: List<HistoryItem> = emptyList(),
    val speechStatus: SpeechStatus = SpeechStatus.INITIALIZING,
    val profile: PatientProfileState = PatientProfileState(),
    val feedback: FeedbackSettings = FeedbackSettings(),
)

class LiveViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val POLL_INTERVAL_MS = 750L
        const val HISTORY_LIMIT = 200
        private val DOB_FORMAT = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.US)
    }

    private val binder = WifiNetworkBinder(application)
    private val client = TiltTalkClient()
    private val tracker = CommandEventTracker()
    private val speech = SpeechEngine(application)
    private val alerts = AlertPlayer(application)
    private var feedback = FeedbackSettings()

    private val _state = MutableStateFlow(LiveState())
    val state: StateFlow<LiveState> = _state.asStateFlow()

    private var pollJob: Job? = null

    init {
        binder.start()
        viewModelScope.launch {
            speech.status.collect { status -> _state.update { it.copy(speechStatus = status) } }
        }
    }

    /** Polling runs only while the activity is started. */
    fun setForeground(visible: Boolean) {
        if (visible) {
            if (pollJob == null) startPolling()
        } else {
            pollJob?.cancel()
            pollJob = null
            speech.stop()
        }
    }

    fun retry() {
        pollJob?.cancel()
        startPolling()
    }

    fun updateFeedback(settings: FeedbackSettings) {
        feedback = settings
        _state.update { it.copy(feedback = settings) }
    }

    fun acknowledgeEmergency() {
        _state.update { it.copy(emergencyPending = false) }
    }

    fun clearHistory() {
        _state.update { it.copy(history = emptyList()) }
    }

    /** Profile is held in memory only; persistence is not implemented yet. */
    fun saveProfile(profile: PatientProfileState) {
        val age = runCatching {
            Age.yearsBetween(LocalDate.parse(profile.dob, DOB_FORMAT), LocalDate.now())
        }.getOrDefault(0)
        _state.update { it.copy(profile = profile.copy(calculatedAge = age)) }
    }

    private fun startPolling() {
        pollJob = viewModelScope.launch {
            while (true) {
                pollOnce()
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    // Requests run one after another in this loop, so they never overlap.
    private suspend fun pollOnce() {
        val result = withContext(Dispatchers.IO) { client.fetch(binder.network) }
        val now = System.currentTimeMillis()
        when (result) {
            is FetchResult.Body -> handleBody(result.text, now)
            is FetchResult.HttpError -> markFailure(LinkState.ERROR, "Device returned HTTP ${result.code}")
            FetchResult.Timeout -> markFailure(LinkState.TIMEOUT, "Device did not respond in time")
            FetchResult.Unreachable -> markFailure(LinkState.UNREACHABLE, "Device not reachable")
        }
    }

    private fun markFailure(link: LinkState, message: String) {
        _state.update { it.copy(link = link, lastError = message) }
    }

    private fun handleBody(body: String, now: Long) {
        when (val parsed = DeviceStatusParser.parse(body)) {
            is ParseResult.Malformed -> markFailure(LinkState.ERROR, "Invalid response from device")
            is ParseResult.Ok -> {
                val status = parsed.status
                val event = tracker.onStatus(status, now)
                val recognized = status.command
                _state.update { s ->
                    s.copy(
                        link = LinkState.CONNECTED,
                        lastError = if (recognized == null) {
                            "Unrecognized command from device: ${status.rawCommand}"
                        } else {
                            null
                        },
                        lastSuccessMs = now,
                        current = recognized?.toUi() ?: s.current,
                        currentDetectedMs = event?.detectedAtMs ?: s.currentDetectedMs,
                        sensorFault = status.mpuAvailable == false,
                        emergencyPending = s.emergencyPending || event?.command?.isEmergency == true,
                        history = if (event != null) {
                            (listOf(toHistoryItem(event)) + s.history).take(HISTORY_LIMIT)
                        } else {
                            s.history
                        },
                    )
                }
                if (event != null) announce(event)
            }
        }
    }

    private fun announce(event: CommandEvent) {
        alerts.play(
            emergency = event.command.isEmergency,
            sound = feedback.soundEnabled,
            vibrate = feedback.vibrationEnabled,
        )
        if (feedback.speechEnabled) {
            speech.speak(event.command.toUi().spokenText, feedback.speechLocale)
        }
    }

    private fun toHistoryItem(event: CommandEvent): HistoryItem {
        val date = Date(event.detectedAtMs)
        return HistoryItem(
            id = "${event.detectedAtMs}-${event.seq ?: 0}",
            command = event.command.toUi(),
            time = SimpleDateFormat("hh:mm a", Locale.US).format(date),
            date = SimpleDateFormat("EEE, MMM d", Locale.US).format(date),
            statusNote = "Received from device",
        )
    }

    private fun DeviceCommand.toUi(): CommandType = CommandType.entries.first { it.rawIntent == wire }

    override fun onCleared() {
        pollJob?.cancel()
        binder.stop()
        speech.shutdown()
        alerts.release()
        super.onCleared()
    }
}
