package com.tilttalk.app.domain

import java.time.LocalDate

object Age {
    /** Whole years between [dob] and [today], accounting for birthdays not yet reached. */
    fun yearsBetween(dob: LocalDate, today: LocalDate): Int {
        require(!dob.isAfter(today)) { "Date of birth is in the future" }
        var years = today.year - dob.year
        if (today < dob.plusYears(years.toLong())) years--
        return years
    }
}
