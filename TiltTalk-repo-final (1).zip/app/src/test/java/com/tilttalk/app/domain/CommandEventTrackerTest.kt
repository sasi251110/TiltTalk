package com.tilttalk.app.domain

import com.tilttalk.app.data.DeviceCommand
import com.tilttalk.app.data.DeviceStatus
import com.tilttalk.app.data.DeviceStatusParser
import com.tilttalk.app.data.ParseResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CommandEventTrackerTest {

    private fun status(json: String): DeviceStatus =
        (DeviceStatusParser.parse(json) as ParseResult.Ok).status

    private fun sequenced(seq: Int, command: String, lastCommand: String, mpu: Boolean = true) =
        """{"command":"$command","lastCommand":"$lastCommand","seq":$seq,"mpuAvailable":$mpu}"""

    private fun unsequenced(command: String) = """{"command":"$command"}"""

    @Test
    fun firstSnapshotOnlySetsBaseline() {
        val tracker = CommandEventTracker()
        assertNull(tracker.onStatus(status(sequenced(3, "WATER", "WATER")), 1_000))
    }

    @Test
    fun newSequenceEmitsEvent() {
        val tracker = CommandEventTracker()
        tracker.onStatus(status(sequenced(0, "NO COMMAND", "NO COMMAND")), 0)
        val event = tracker.onStatus(status(sequenced(1, "NO COMMAND", "WATER")), 1_000)
        assertEquals(DeviceCommand.WATER, event!!.command)
        assertEquals(1L, event.seq)
    }

    @Test
    fun sameSequenceDoesNotRepeat() {
        val tracker = CommandEventTracker()
        tracker.onStatus(status(sequenced(0, "NO COMMAND", "NO COMMAND")), 0)
        tracker.onStatus(status(sequenced(1, "WATER", "WATER")), 1_000)
        assertNull(tracker.onStatus(status(sequenced(1, "WATER", "WATER")), 2_000))
    }

    @Test
    fun repeatedCommandWithNewSequenceEmitsAgain() {
        val tracker = CommandEventTracker()
        tracker.onStatus(status(sequenced(1, "WATER", "WATER")), 0)
        val second = tracker.onStatus(status(sequenced(2, "WATER", "WATER")), 1_000)
        assertEquals(DeviceCommand.WATER, second!!.command)
    }

    @Test
    fun noCommandNeverEmits() {
        val tracker = CommandEventTracker()
        tracker.onStatus(status(sequenced(0, "NO COMMAND", "NO COMMAND")), 0)
        assertNull(tracker.onStatus(status(sequenced(2, "NO COMMAND", "NO COMMAND")), 1_000))
    }

    @Test
    fun sensorFaultEmitsNothing() {
        val tracker = CommandEventTracker()
        tracker.onStatus(status(sequenced(0, "NO COMMAND", "NO COMMAND")), 0)
        assertNull(tracker.onStatus(status(sequenced(1, "NO COMMAND", "WATER", mpu = false)), 1_000))
    }

    @Test
    fun withoutSequenceFallsBackToTransitions() {
        val tracker = CommandEventTracker()
        tracker.onStatus(status(unsequenced("NO COMMAND")), 0)
        assertEquals(DeviceCommand.WATER, tracker.onStatus(status(unsequenced("WATER")), 1_000)!!.command)
        assertNull(tracker.onStatus(status(unsequenced("WATER")), 2_000))
        tracker.onStatus(status(unsequenced("NO COMMAND")), 3_000)
        assertEquals(DeviceCommand.WATER, tracker.onStatus(status(unsequenced("WATER")), 4_000)!!.command)
    }
}
