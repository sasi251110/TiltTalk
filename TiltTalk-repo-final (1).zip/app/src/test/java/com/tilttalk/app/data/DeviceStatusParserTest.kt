package com.tilttalk.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DeviceStatusParserTest {

    private fun ok(json: String): DeviceStatus {
        val result = DeviceStatusParser.parse(json)
        assertTrue("expected Ok but was $result", result is ParseResult.Ok)
        return (result as ParseResult.Ok).status
    }

    @Test
    fun parsesFirmwareResponse() {
        val s = ok(
            """{"device":"TiltTalk","command":"WATER","lastCommand":"WATER",""" +
                """"pitch":-42.3,"roll":3.2,"uptime":120000,"timestamp":118500,""" +
                """"locked":true,"seq":4,"mpuAvailable":true}"""
        )
        assertEquals(DeviceCommand.WATER, s.command)
        assertEquals("WATER", s.rawCommand)
        assertEquals("WATER", s.rawLastCommand)
        assertEquals(-42.3, s.pitch!!, 0.001)
        assertEquals(4L, s.seq)
        assertEquals(true, s.mpuAvailable)
    }

    @Test
    fun missingOptionalFieldsBecomeNull() {
        val s = ok("""{"command":"HELP"}""")
        assertEquals(DeviceCommand.HELP, s.command)
        assertNull(s.seq)
        assertNull(s.pitch)
        assertNull(s.mpuAvailable)
    }

    @Test
    fun unknownCommandKeepsRawValue() {
        val s = ok("""{"command":"DANCE"}""")
        assertNull(s.command)
        assertEquals("DANCE", s.rawCommand)
    }

    @Test
    fun noCommandIsParsed() {
        assertEquals(DeviceCommand.NO_COMMAND, ok("""{"command":"NO COMMAND"}""").command)
    }

    @Test
    fun malformedJsonIsRejected() {
        assertTrue(DeviceStatusParser.parse("{not json") is ParseResult.Malformed)
    }

    @Test
    fun missingCommandIsRejected() {
        assertTrue(DeviceStatusParser.parse("""{"pitch":1.0}""") is ParseResult.Malformed)
    }
}
