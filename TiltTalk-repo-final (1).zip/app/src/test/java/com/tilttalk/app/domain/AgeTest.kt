package com.tilttalk.app.domain

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class AgeTest {
    @Test
    fun birthdayNotYetReachedThisYear() =
        assertEquals(69, Age.yearsBetween(LocalDate.of(1956, 3, 14), LocalDate.of(2026, 3, 13)))

    @Test
    fun birthdayToday() =
        assertEquals(70, Age.yearsBetween(LocalDate.of(1956, 3, 14), LocalDate.of(2026, 3, 14)))

    @Test
    fun leapDayBirthdayInNonLeapYear() =
        assertEquals(1, Age.yearsBetween(LocalDate.of(2000, 2, 29), LocalDate.of(2001, 2, 28)))

    @Test
    fun leapDayBirthdayOnLeapYear() =
        assertEquals(4, Age.yearsBetween(LocalDate.of(2000, 2, 29), LocalDate.of(2004, 2, 29)))
}
