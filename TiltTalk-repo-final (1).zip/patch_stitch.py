import re
import pathlib

p = pathlib.Path("app/src/main/java/com/tilttalk/app/ui/screens/TiltTalkScreens.kt")
s = p.read_text()

def rep(old, new):
    global s
    n = s.count(old)
    assert n == 1, f"expected 1 match, got {n}: {old[:80]!r}"
    s = s.replace(old, new)

def rx(pattern, new):
    global s
    n = len(re.findall(pattern, s, re.S))
    assert n == 1, f"regex matched {n} times: {pattern[:70]!r}"
    s = re.sub(pattern, lambda m: new, s, count=1, flags=re.S)

# --- Fake defaults in profile / home / overlay ---
rep('val fullName: String = "Eleanor Vance"', 'val fullName: String = ""')
rep('val dob: String = "March 14, 1956"', 'val dob: String = ""')
rep('val calculatedAge: Int = 68', 'val calculatedAge: Int = 0')
rep('val wardLocation: String = "Room 304, Bed B (Memorial Care Unit)"', 'val wardLocation: String = ""')
rep('val primaryNurse: String = "Sarah Jenkins, RN"', 'val primaryNurse: String = ""')
rep('val emergencyContact: String = "Michael Vance (Son) - (555) 234-5678"', 'val emergencyContact: String = ""')
rep('currentCommand: CommandType = CommandType.WATER,', 'currentCommand: CommandType = CommandType.NO_COMMAND,')
rep('lastDetectedTime: String = "2 min ago",', 'lastDetectedTime: String = "",')
rep('isDeviceConnected: Boolean = true,', 'isDeviceConnected: Boolean = false,')
rep('triggerTime: String = "10:43:12 AM (Just now)",', 'triggerTime: String = "",')
rx(r'historyList: List<HistoryItem> = listOf\(.*?\n    \),\n    selectedFilterIndex',
   'historyList: List<HistoryItem> = emptyList(),\n    selectedFilterIndex')

# --- Home: real recent history instead of hard-coded sample rows ---
rep('    isDeviceConnected: Boolean = false,\n',
    '    isDeviceConnected: Boolean = false,\n    recentItems: List<HistoryItem> = emptyList(),\n')
rx(r'val sampleRecent = listOf\(.*?\n\s*\)\n',
   'val sampleRecent = recentItems.take(3).map { Triple(it.command, it.time, it.statusNote) }\n')

# --- Connection: only show diagnostics the firmware actually reports ---
rep('    isConnected: Boolean = true,\n',
    '    isConnected: Boolean = true,\n    sensorAvailable: Boolean = false,\n')
rep('    hardwarePingMs: Int = 12,\n', '')
rep('    batteryRemainingPct: Int = 84,\n', '')
rx(r'\n\s*Row\(modifier = Modifier\.fillMaxWidth\(\), horizontalArrangement = Arrangement\.SpaceBetween\) \{\n\s*Text\("Hardware Ping:".*?\n\s*\}\n',
   '\n')
rx(r'val diagnostics = listOf\(.*?\n\s*\)\n',
   'val diagnostics = listOf(\n'
   '                        Triple(Icons.Outlined.MotionPhotosOn, "Sensor Status", '
   'if (sensorAvailable) "Reported by device" else "Not reported by device")\n'
   '                    )\n')

# --- Settings: toggles driven by parameters, not local state ---
rep('    onClearAllLogs: () -> Unit = {}\n) {',
    '    onClearAllLogs: () -> Unit = {},\n'
    '    speakAloud: Boolean = true,\n'
    '    onSpeakAloudChange: (Boolean) -> Unit = {},\n'
    '    alertSound: Boolean = true,\n'
    '    onAlertSoundChange: (Boolean) -> Unit = {},\n'
    '    vibration: Boolean = true,\n'
    '    onVibrationChange: (Boolean) -> Unit = {}\n) {')
rep('    var speakMessagesAloud by remember { mutableStateOf(true) }\n', '')
rep('    var alertSoundOnEmergency by remember { mutableStateOf(true) }\n', '')
rep('    var hapticVibrationFeedback by remember { mutableStateOf(true) }\n', '')
rep('checked = speakMessagesAloud,', 'checked = speakAloud,')
rep('onCheckedChange = { speakMessagesAloud = it },', 'onCheckedChange = onSpeakAloudChange,')
rep('checked = alertSoundOnEmergency,', 'checked = alertSound,')
rep('onCheckedChange = { alertSoundOnEmergency = it },', 'onCheckedChange = onAlertSoundChange,')
rep('checked = hapticVibrationFeedback,', 'checked = vibration,')
rep('onCheckedChange = { hapticVibrationFeedback = it },', 'onCheckedChange = onVibrationChange,')

# --- Accuracy of displayed facts and copy ---
rep('"ESP32 98dB Buzzer Active • Local Vibration Active"', '"Alert shown on this phone"')
rep('"500 ms (Fast Response)"', '"750 ms"')
rep('"v1.2.0 (Build 44 - Jetpack Compose Native)"', '"0.1.0-prototype"')
rep('"Firmware Target: TiltTalk-ESP32 v2.1"', '"Requires the patched TiltTalk firmware"')
rep('translates them immediately into clinical critical needs.', 'shows them to caregivers on this phone.')
rep('Explore Offline Demo Mode / Skip Profile', 'Skip profile setup')
rep('Last successful command received 4 minutes ago.', 'Check the last contact time on the Connection screen.')

p.write_text(s)
print("Stitch screens patched")

# --- Verification: list any remaining sample or unsupported content ---
for pat in ["Eleanor", "Sarah Jenkins", "Michael Vance", "sampleRecent = listOf", "Caregiver",
            "SMS", "Buzzer", "Demo", "Battery", "Hardware Ping", "2 min ago", "10:43"]:
    for i, line in enumerate(s.splitlines(), 1):
        if pat in line:
            print(f"REMAINING [{pat}] line {i}: {line.strip()[:110]}")
